package org.zerock.goods.vo;

import lombok.Data;

@Data
public class GoodsImageVO {
	
	private Long goods_img_no;
	private String goods_img_name;
	private Long goods_no;
	public String getImage_name() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
