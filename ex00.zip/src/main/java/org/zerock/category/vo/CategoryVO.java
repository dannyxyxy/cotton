package org.zerock.category.vo;

import lombok.Data;

@Data
public class CategoryVO {
	
	private Integer cate_code1;
	private Integer cate_code2;
	private String cate_name;
	
	
}
